public class NullPointerExceptionThrown{
    public static void main(String[] args) {
        String nullVariable = null;
        System.out.println(nullVariable.equals(null));
    }
}