/**
 * Sounds interface
 * 
 * Defines an abstract method: playSound()
 */
public interface Sounds {
    void playSound();
}