/**
 * Retatoble interface
 * 
 * Defines an abstract method: rotateObject()
 */
public interface Rotatable {
    void rotateObject();
}