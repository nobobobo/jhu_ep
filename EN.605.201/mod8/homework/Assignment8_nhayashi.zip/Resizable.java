/**
 * Resizable interface
 * 
 * Defines an abstract method: resizeObject()
 */

public interface Resizable {
    void resizeObject();
}