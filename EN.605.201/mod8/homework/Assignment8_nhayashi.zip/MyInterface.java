/**
 * MyInterface interface, extends from Drawable, Resizeble, Rotatable, Sounds interfaces
 */

public interface MyInterface extends Drawable, Resizable, Rotatable,Sounds{
}